package com.cg.hotelManagement.exception;

public class HotelManagementException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HotelManagementException(String msg){
		super(msg);
	}
}
