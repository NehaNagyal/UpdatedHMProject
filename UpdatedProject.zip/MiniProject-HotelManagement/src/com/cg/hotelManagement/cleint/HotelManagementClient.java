package com.cg.hotelManagement.cleint;

import java.util.Scanner;

import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.exception.HotelManagementException;
import com.cg.hotelManagement.service.HotleManagementServiceImpl;

public class HotelManagementClient {

	public static void main(String[] args)  {
		Scanner sc= new Scanner(System.in);
		
		HotleManagementServiceImpl hotelMangementService=new HotleManagementServiceImpl();
		UserDetails userDetails=new UserDetails();
		
		System.out.println("Welcome to hotel Management System");
		
		//*************************************************************
		//Adding a new user hotel employee/customer to the hotel management system
		
		/*System.out.println("Enter User Name :: ");
		String name=sc.next();
		userDetails.setUserName(name);
		System.out.println("Create your Password ::");
		String password=sc.next();
		userDetails.setPassword(password);
		System.out.println("Enter a unique user Id :: ");
		String userId=sc.next();
		userDetails.setUserId(userId);
		System.out.println("Enter your role :: ");
		String role=sc.next();
		userDetails.setRole(role);
		System.out.println("Enter your mobile number :: ");
		String mobile=sc.next();
		userDetails.setMobileNo(mobile);
		System.out.println("Enter your phone number :: ");
		String pNo=sc.next();
		userDetails.setPhone(pNo);
		System.out.println("Enter your home city :: ");
		String city=sc.next();
		userDetails.setAddress(city);
		System.out.println("Enter your email Id :: ");
		String eMail=sc.next();
		userDetails.setEmail(eMail);
		
		hotelMangementService.addUser(userDetails); */
		//*************************************************************
		//ADMIN LOGIN since there can be only one admin --> so values are hardcoded in service layer.
		//System.out.println(hotelMangementService.adminLogin("System", "Capgemini123"));
		//*************************************************************
		//User login 
		System.out.println("Enter UserID ::");
		String uId=sc.next();
		System.out.println("Enter Password ::");
		String pwd = sc.next();
		try {
			if(hotelMangementService.userLogin(uId, pwd)==1)
				System.out.println("Welcome!!Signed in");
			else
				System.err.println("Your password does not match.");
		} catch (HotelManagementException e) {
			System.err.println("Exception::UserID Does not exist");
		}
		
	}
}
