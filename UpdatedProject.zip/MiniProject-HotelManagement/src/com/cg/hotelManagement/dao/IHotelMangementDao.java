package com.cg.hotelManagement.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.BookingDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public interface IHotelMangementDao {
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();

	public UserDetails userLogin(String userName) throws HotelManagementException;
	
	public void addUser(UserDetails userDetails);
	
	public List<BookingDetails> viewBookingDetailsFromDate(LocalDate date);
	
	public List<Hotels> searchHotels(String city,double minPrice,double maxPrice,int rating);
	
	public List<UserDetails> viewGuestListSpecificHotels(String hotellId);
	
	public List<BookingDetails> viewBookingSpecificHotel(String hotelId);
}
